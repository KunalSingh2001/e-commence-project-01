import React from "react";
import "../components/Heading.css";
function Heading() {
    return (
        <div className="bg-secondary text-white d-flex justify-content-center align-items-center py-5 font-times fs-20">
            <span>The Generics</span>
        </div>
    );
}

export default Heading;
