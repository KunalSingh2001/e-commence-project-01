import React from "react";
import "./Cart.css";

function Cart() {
    return (
        <div id="parent">
            <h1>Hello I am Showing</h1>
        </div>
    );
}

export default Cart;
