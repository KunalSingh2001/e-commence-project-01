import React from "react";

function Footer() {
    return (
        <div className="bg-info text-white d-flex justify-content-center align-items-center py-4 font-times fs-20 mt-3">
            <p>The Generics</p>
        </div>
    );
}

export default Footer;
