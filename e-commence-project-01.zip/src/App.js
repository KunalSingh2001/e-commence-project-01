import React, { useState } from "react";
import "./App.css";
import Header from "./components/elements/Header";
import Footer from "./components/elements/Footer";
import Heading from "./components/Heading";
import Store from "./components/Store";
import Modal from "./components/Portal/Modal";
import Cart from "./components/Cart";
function App() {
    const [showCart, setShowCart] = useState(false);
    const productsArr = [
        {
            title: "Colors",
            price: 100,
            imageUrl:
                "https://prasadyash2411.github.io/ecom-website/img/Album%201.png",
        },
        {
            title: "Black and white Colors",
            price: 50,
            imageUrl:
                "https://prasadyash2411.github.io/ecom-website/img/Album%202.png",
        },
        {
            title: "Yellow and Black Colors",
            price: 70,
            imageUrl:
                "https://prasadyash2411.github.io/ecom-website/img/Album%203.png",
        },
        {
            title: "Blue Color",
            price: 100,
            imageUrl:
                "https://prasadyash2411.github.io/ecom-website/img/Album%204.png",
        },
    ];

    function hideShowCart() {
        setShowCart((prev) => !prev);
    }

    return (
        <>
            <Header handleHideShowCart={hideShowCart} />
            <Heading />
            <Store products={productsArr} />
            {showCart && (
                <Modal>
                    <Cart />
                </Modal>
            )}
            <Footer />
        </>
    );
}

export default App;
